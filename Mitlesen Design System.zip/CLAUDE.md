# Mitlesen Design System — working notes

- **用中文回复用户。** The user prefers responses in Chinese (说中文).
- This is the **共读 · Mitlesen** design system. Component namespace in `@dsCard`
  HTML: `window.MitlesenDesignSystem_737635`.
- After editing sources, run `check_design_system` until clean.
- Groups in the Design System tab: Brand, Colors, Type, Spacing, Components,
  Mitlesen Reader, Mitlesen Mobile, Vorklang Letters.
- Keep the two worlds distinct: warm letter-paper (纸) for reading content,
  cool periwinkle glass (界) for chrome. Emotion = wax dots, never colour bars.
